








<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 order-lg-1 order-md-2 order-1">
                <div class="CustomerServices">
                    <h6>Customer services</h6>
                    <ul>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Shipping Policy</a></li>
                        <li><a href="#">Return Policy</a></li>
                        <li><a href="#">Disclaimer</a></li>
                        <li><a href="#">Terms and Condition</a></li>
                        <li><a href="#">Sitemap</a></li>
                    </ul>
                    <ul>
                        <li>
                            <h6>Follow Us</h6>
                        </li>
                        <li>
                            <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                            <a href="#"><i class="fa-brands fa-twitter"></i></a>
                            <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-5 col-md-8 order-lg-1 order-md-1 order-2">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-6 ">
                        <div class="myAccount">
                            <h6>My Account</h6>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-6 col-12 ">
                        <div class="Categories">
                            <h6>Categories</h6>
                            <ul>
                                <li><a href="#">Birthday</a></li>
                                <li><a href="#">Celebration</a></li>
                                <li><a href="#">Wedding</a></li>
                                <li><a href="#">Collections</a></li>
                                <li><a href="#">Anniversary</a></li>
                                <li><a href="#">Same Day</a></li>
                                <li><a href="#">Corporate</a></li>
                                <li><a href="#">Gifts</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="payments">
                            <h6>All Cards Acceptable</h6>
                            <ul>
                                <li><a href="#"><img src="assets/images/payment.png" alt=""></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 order-lg-1 order-md-3 order-3">
                <div class="labelsBox">
                    <ul>
                        <li><a href="#">Best florist in Dubai</a></li>
                        <li><a href="#">Fastest & Safest Flower Delivery</a></li>
                        <li><a href="#">Beautiful Hand-Tied Bouquets</a></li>
                        <li><a href="#">Flower </a></li>
                        <li><a href="#">Mid-Night Delivery</a></li>
                        <li><a href="#"> Floral arrangements</a></li>
                        <li><a href="#">Safe &Trusted</a></li>
                        <li><a href="#">24*7 Online Flower Delivery in Dubai</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>




<div class="bottomFooter">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-12 bottomFooterLeft">
                <ul>
                    <li><a href="index.php"><img src="assets/images/logo.svg" alt=""></a></li>
                    <li><p>Copyright <span>&copy;</span>2022 Creative Florist</p></li>
                </ul>
            </div>
            <div class="col-lg-7 bottomFooterRight">
                <ul>
                    <li>
                        <a href="#">
                            <p>Head Office:</p>
                            <p>26 Wyle Cop, Shrewsbury, Shropshire, SY1 1XD</p>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <p>Tel:</p>
                            <p>01743 234500</p>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <p>Email:</p>
                            <p>info@creativeflorist.com</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>







<script src="assets/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>-->
<script src="assets/vendor/slick/slick.min.js"></script>
<script src="assets/vendor/select2/js/select2.full.min.js"></script>
<script src="assets/js/jquery.fancybox.min.js"></script>
<script src="assets/js/packery.pkgd.min.js"></script>
<script src="assets/js/jquery.star-rating-svg.js"></script>
<script src="assets/js/custom.js"></script>
<script src="assets/js/scripts.js"></script>

</body>
</html>
