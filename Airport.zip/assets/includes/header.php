<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CFF</title>
    <link rel="icon" type="image/x-icon" href="assets/images/Logo.png">
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="assets/vendor/slick/slick.min.css">
    <link rel="stylesheet" href="assets/vendor/slick/slick-theme.min.css">
    <link rel="stylesheet" href="assets/vendor/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/star-rating-svg.css">
    <link rel="stylesheet" href="assets/vendor/select2/css/select2.min.css">
    <link rel="stylesheet" href="assets/vendor/select2-bootstrap4-theme/select2-bootstrap4.min.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</head>
<body>

<div class="topstrip">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p>Welcome To Creative Florist</p>
            </div>
        </div>
    </div>
</div>


<div class="topHeader">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-4 col-3 topHeaderLeft">
                <ul>
                    <li><a href="#"><img src="assets/images/svg/search.svg" alt=""></a></li>
                </ul>
            </div>
            <div class="d-block d-md-none col-6 logoCenter">
                <a class="navbar-brand" href="index.php"><img src="assets/images/logo.svg" alt=""></a>
            </div>
            <div class="col-lg-6 col-md-8 col-3 topHeaderRight">
                <ul class="social">
                    <li><a href="tel:+01743 234500"><img src="assets/images/svg/call.svg" alt=""><p>01743 234500</p></a></li>
                    <li><a href="mailto:info@creativeflorist.com"><img src="assets/images/svg/email.svg" alt=""><p>info@creativeflorist.com</p></a></li>
                </ul>
                <ul class="Shopping">
                    <li><a href="#" data-bs-toggle="modal" data-bs-target="#loginModal"><img src="assets/images/svg/user.svg" alt=""></a></li>
                    <li><a href="#"><img src="assets/images/svg/favourite.svg" alt=""></a></li>
                    <li><a href="#"><img src="assets/images/svg/cart.svg" alt=""></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>


<header>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="index.php"><img src="assets/images/logo.svg" alt=""></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto mb-2 mb-lg-0 ms-5">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About Us</a>
                    </li>




                    <li id="link-1" class="nav-item dropdown-hover-service desktopMenu">
                        <a class="nav-link dropdown-hover-button" href="#">Product<i class="fas fa-caret-down"></i></a>
                        <div class="dropdown-hover-content">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="listingContents">
                                        <div class="row">
                                            <div class="col-lg-6 menuContents">
                                                <div class="menuContentsLeft">
                                                    <ul>
                                                        <li><a href="#">Birthday</a></li>
                                                        <li><a href="#">Wedding</a></li>
                                                        <li><a href="#">Anniversary</a></li>
                                                        <li><a href="#">Corporate</a></li>
                                                    </ul>
                                                </div>
                                                <div class="menuContentsRight">
                                                    <picture>
                                                        <img src="assets/images/flower.png" alt="">
                                                    </picture>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 menuContents">
                                                <div class="menuContentsLeft">
                                                    <ul>
                                                        <li><a href="#">Birthday</a></li>
                                                        <li><a href="#">Wedding</a></li>
                                                        <li><a href="#">Anniversary</a></li>
                                                        <li><a href="#">Corporate</a></li>
                                                    </ul>
                                                </div>
                                                <div class="menuContentsRight">
                                                    <picture>
                                                        <img src="assets/images/flower.png" alt="">
                                                    </picture>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="exploreContents">
                                        <div class="row exploreContents">
                                            <div class="col-md-12">
                                                <div class="exploreContentsBox">
                                                    <picture>
                                                        <img src="assets/images/flowers1.png" alt="">
                                                    </picture>
                                                    <div class="contents">
                                                        <h5>Fresh flowers for any special occasion</h5>
                                                        <a href="#">Explore More</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </li>




                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>




<div class="fixedrightSidebar">
    <div class="socialMedia">
        <div class="QuickSideRightBar QuickSideRightBarWhatsapp">
            <a href="https://wa.me/+97145488867" target="blank">
                <div class="imgboz">
                    <img src="assets/images/svg/whatsappFixed.svg" alt="" class="CallRight">
                </div>
                <div class="slideLeft">
                    <span class="textRight">+971 454 888 67</span>
                </div>
            </a>
        </div>
    </div>
</div>


<!--<div class="fixedBottomBar">-->
<!--   <div class="container">-->
<!--       <div class="row">-->
<!--           <ul>-->
<!--               <li><a href="https://wa.me/+97145488867" target="blank"><img src="assets/images/calling.png" alt=""></a></li>-->
<!--               <li><a href="tel:+971 454 888 67"><img src="assets/images/whatsapping.png" alt=""></a></li>-->
<!--               <li><a href="#" data-bs-toggle="modal" data-bs-target="#quickEnquiry" class="quoteModal"  data-bs-toggle="modal" data-bs-target="#quickEnquiryModal">Get Quote</a></li>-->
<!--           </ul>-->
<!--       </div>-->
<!--   </div>-->
<!--</div>-->


<!--login popup -->
<div class="modal fade loginpopup" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <img src="assets/images/popupImage.png" alt="">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               <h3>Login</h3>
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="User Name">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                    </div>
                    <div class="forgot">
                        <a href="#" data-bs-toggle="modal" data-bs-target="#forgotModal" aria-label="Close" data-bs-dismiss="modal">Forgotten Password?</a>
                    </div>
                    <button type="submit" class="primary_btn">login</button>
                </form>
            </div>
            <div class="modal-footer">
                <div class="signwith">
                    <p>Sign with</p>
                </div>
                <div class="btngroup">
                    <a href="#" data-bs-toggle="modal" data-bs-target="#registerModal" aria-label="Close" data-bs-dismiss="modal"><img src="assets/images/svg/popupgoogle.svg" alt=""></a>
                    <a href="#"><img src="assets/images/svg/popupFacebook.svg" alt=""></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--login popup -->


<!--Register popup -->
<div class="modal fade loginpopup" id="registerModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <img src="assets/images/popupImage.png" alt="">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h3>Register</h3>
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Full Name">
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                    </div>
                    <div class="forgot">
                        <a href="#">Forgotten Password?</a>
                    </div>
                    <button type="submit" class="primary_btn" data-bs-toggle="modal" data-bs-target="#loginModal" aria-label="Close" data-bs-dismiss="modal">Register</button>
                </form>
            </div>
            <div class="modal-footer">
                <div class="signwith">
                    <p>Sign with</p>
                </div>
                <div class="btngroup">
                    <a href="#"><img src="assets/images/svg/popupgoogle.svg" alt=""></a>
                    <a href="#"><img src="assets/images/svg/popupFacebook.svg" alt=""></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Register popup -->


<!--Reset Password -->
<div class="modal fade loginpopup" id="forgotModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <img src="assets/images/popupImage.png" alt="">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h3>Reset your password</h3>
                <form>
                    <div class="form-group">
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email">
                    </div>
                    <button type="submit" class="primary_btn">Verify</button>
                </form>
            </div>
            <div class="modal-footer">
                <div class="signsin">
                    <p>Back to <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" aria-label="Close" data-bs-dismiss="modal">Sign in</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Reset Password -->

